document.getElementById('pergunta').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    const pergunta = e.target.value.toLowerCase();
    const resposta = document.getElementById('respostaIA');

    const respostas = {
      'preço': 'Fazemos orçamentos personalizados. Fale pelo WhatsApp!',
      'custa': 'O valor depende do projeto. Podemos conversar melhor no WhatsApp!',
      'tempo': 'O prazo médio é de 5 a 10 dias úteis.',
      'demora': 'Geralmente entregamos o site em até 10 dias.',
      'formas de pagamento': 'Aceitamos Pix, boleto e cartão de crédito.',
      'pagamento': 'Trabalhamos com entrada + entrega final. Podemos negociar!',
      'suporte': 'Oferecemos suporte técnico por WhatsApp ou e-mail após a entrega.',
      'hospedagem': 'Podemos te ajudar a escolher ou configurar a hospedagem.',
      'domínio': 'Se ainda não tem, te orientamos a registrar um domínio próprio.',
      'personalização': 'Todos os sites são 100% personalizados para o cliente.',
      'responsivo': 'Sim! Todos os nossos sites funcionam em celular, tablet e computador.',
      'redes sociais': 'Fazemos integração com Instagram, WhatsApp, YouTube e mais.',
      'e-commerce': 'Também fazemos lojas virtuais com carrinho, pagamento e tudo mais!'
    };

    let encontrada = false;
    for (let chave in respostas) {
      if (pergunta.includes(chave)) {
        resposta.innerText = respostas[chave];
        encontrada = true;
        break;
      }
    }

    if (!encontrada) {
      resposta.innerText = 'Desculpe, ainda estou aprendendo! Tente perguntar de outro jeito.';
    }
  }
});
